Imports System.Data.SqlClient

Public Class FormSinhVien
    Dim conn As New SqlConnection("Data Source=.;Initial Catalog=QLSinhVien;Integrated Security=True")
    Private editMaSV As String = Nothing

    Public Sub New()
        InitializeComponent()
    End Sub

    Public Sub New(ma As String)
        InitializeComponent()
        editMaSV = ma
        LoadDataToForm()
    End Sub

    Private Sub LoadDataToForm()
        If editMaSV Is Nothing Then Return
        Dim cmd As New SqlCommand("SELECT * FROM SinhVien WHERE MaSV=@MaSV", conn)
        cmd.Parameters.AddWithValue("@MaSV", editMaSV)
        Dim da As New SqlDataAdapter(cmd)
        Dim dt As New DataTable()
        da.Fill(dt)
        If dt.Rows.Count > 0 Then
            txtMaSV.Text = dt.Rows(0)("MaSV").ToString()
            txtHoTen.Text = dt.Rows(0)("HoTen").ToString()
            dtNgaySinh.Value = Date.Parse(dt.Rows(0)("NgaySinh").ToString())
            cboGioiTinh.Text = dt.Rows(0)("GioiTinh").ToString()
            txtLop.Text = dt.Rows(0)("Lop").ToString()
            txtMaSV.Enabled = False
        End If
    End Sub

    Private Sub btnLuu_Click(sender As Object, e As EventArgs) Handles btnLuu.Click
        If editMaSV Is Nothing Then
            Dim cmd As New SqlCommand("INSERT INTO SinhVien VALUES(@MaSV,@HoTen,@NgaySinh,@GioiTinh,@Lop)", conn)
            cmd.Parameters.AddWithValue("@MaSV", txtMaSV.Text)
            cmd.Parameters.AddWithValue("@HoTen", txtHoTen.Text)
            cmd.Parameters.AddWithValue("@NgaySinh", dtNgaySinh.Value.Date)
            cmd.Parameters.AddWithValue("@GioiTinh", cboGioiTinh.Text)
            cmd.Parameters.AddWithValue("@Lop", txtLop.Text)
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            MessageBox.Show("Đã thêm sinh viên thành công!")
            Me.Close()
        Else
            Dim cmd As New SqlCommand("UPDATE SinhVien SET HoTen=@HoTen, NgaySinh=@NgaySinh, GioiTinh=@GioiTinh, Lop=@Lop WHERE MaSV=@MaSV", conn)
            cmd.Parameters.AddWithValue("@MaSV", txtMaSV.Text)
            cmd.Parameters.AddWithValue("@HoTen", txtHoTen.Text)
            cmd.Parameters.AddWithValue("@NgaySinh", dtNgaySinh.Value.Date)
            cmd.Parameters.AddWithValue("@GioiTinh", cboGioiTinh.Text)
            cmd.Parameters.AddWithValue("@Lop", txtLop.Text)
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            MessageBox.Show("Đã cập nhật thông tin sinh viên!")
            Me.Close()
        End If
    End Sub
End Class
