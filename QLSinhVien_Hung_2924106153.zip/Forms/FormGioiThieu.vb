Public Class FormGioiThieu
    Private Sub FormGioiThieu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblTenPM.Text = "PHẦN MỀM QUẢN LÝ SINH VIÊN"
        lblTacGia.Text = "Sinh viên: Nguyễn Quang Hưng - Lớp TH29.28 - MSV 2924106153"
    End Sub
End Class
