Imports System.Data.SqlClient

Public Class FormMain
    Dim conn As New SqlConnection("Data Source=.;Initial Catalog=QLSinhVien;Integrated Security=True")

    Private Sub FormMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadData()
    End Sub

    Sub LoadData()
        Dim da As New SqlDataAdapter("SELECT * FROM SinhVien", conn)
        Dim dt As New DataTable()
        da.Fill(dt)
        dgvSinhVien.DataSource = dt
    End Sub

    Private Sub btnThem_Click(sender As Object, e As EventArgs) Handles btnThem.Click
        Dim f As New FormSinhVien()
        f.ShowDialog()
        LoadData()
    End Sub

    Private Sub btnSua_Click(sender As Object, e As EventArgs) Handles btnSua.Click
        If dgvSinhVien.CurrentRow Is Nothing Then Return
        Dim ma As String = dgvSinhVien.CurrentRow.Cells("MaSV").Value.ToString()
        Dim f As New FormSinhVien(ma)
        f.ShowDialog()
        LoadData()
    End Sub

    Private Sub btnXoa_Click(sender As Object, e As EventArgs) Handles btnXoa.Click
        If dgvSinhVien.CurrentRow Is Nothing Then Return
        Dim ma As String = dgvSinhVien.CurrentRow.Cells("MaSV").Value.ToString()
        Dim cmd As New SqlCommand("DELETE FROM SinhVien WHERE MaSV=@MaSV", conn)
        cmd.Parameters.AddWithValue("@MaSV", ma)
        conn.Open()
        cmd.ExecuteNonQuery()
        conn.Close()
        LoadData()
    End Sub
End Class
