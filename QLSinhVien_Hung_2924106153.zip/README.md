# QLSinhVien_VBNet
Đồ án: Phần mềm Quản lý Sinh viên - VB.NET
Sinh viên: Nguyễn Quang Hưng
Lớp: TH29.28
MSV: 2924106153

## Hướng dẫn nhanh
1. Mở file Database/QLSinhVien.sql trong SQL Server Management Studio, chạy để tạo cơ sở dữ liệu và dữ liệu mẫu.
2. Mở project bằng Visual Studio (tạo mới Windows Forms project, thêm các file .vb vào).
3. Chỉnh chuỗi kết nối trong code nếu cần (Data Source nếu dùng SQLEXPRESS).
4. Chạy và kiểm tra các chức năng: Thêm, Sửa, Xóa.
